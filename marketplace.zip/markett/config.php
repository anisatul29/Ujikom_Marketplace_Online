<?php
// config.php - Koneksi Database & Fungsi Auto ID
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'marketplace';//sesuaikan sama database

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fungsi untuk Generate ID Varchar Otomatis (Contoh: PRD001, TRX001)
function generateID($koneksi, $tabel, $kolom_id, $prefix) {
    $query = mysqli_query($koneksi, "SELECT $kolom_id FROM $tabel ORDER BY $kolom_id DESC LIMIT 1");
    $data = mysqli_fetch_assoc($query);

    if ($data) {
        $last_id = $data[$kolom_id];
        $number = (int) substr($last_id, strlen($prefix));
        $next_number = $number + 1;
    } else {
        $next_number = 1;
    }

    // Format angka menjadi 3 digit (contoh: PRD001)
    return $prefix . str_pad($next_number, 3, "0", STR_PAD_LEFT);
}
?>