<?php
// admin/produk.php - CRUD Produk & Foto Marketplace
require_once '../config.php';

// Cek autentikasi admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

// 1. CREATE (Tambah Produk Baru + Upload Foto)
if (isset($_POST['tambah_produk'])) {
    $id_produk   = generateID($koneksi, 'produk', 'id_produk', 'PRD');
    $id_kategori = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $deskripsi   = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $harga       = (int)$_POST['harga'];
    $stok        = (int)$_POST['stok'];

    // Process Upload Gambar
    $foto_nama = 'default.jpg';
    if (!empty($_FILES['foto']['name'])) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $foto_nama = time() . '_' . rand(100, 999) . '.' . $ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], '../uploads/' . $foto_nama);
    }

    $query = "INSERT INTO produk (id_produk, id_kategori, nama_produk, deskripsi, harga, stok, foto) 
              VALUES ('$id_produk', '$id_kategori', '$nama_produk', '$deskripsi', $harga, $stok, '$foto_nama')";
    mysqli_query($koneksi, $query);
    header('Location: produk.php');
    exit;
}

// 2. UPDATE (Edit Produk + Ganti Foto)
if (isset($_POST['update_produk'])) {
    $id_produk   = mysqli_real_escape_string($koneksi, $_POST['id_produk']);
    $id_kategori = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $deskripsi   = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $harga       = (int)$_POST['harga'];
    $stok        = (int)$_POST['stok'];
    $foto_lama   = mysqli_real_escape_string($koneksi, $_POST['foto_lama']);

    $foto_nama = $foto_lama;

    // Jika admin mengunggah foto baru
    if (!empty($_FILES['foto']['name'])) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $foto_nama = time() . '_' . rand(100, 999) . '.' . $ext;
        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], '../uploads/' . $foto_nama)) {
            // Hapus foto lama jika bukan default
            if ($foto_lama != 'default.jpg' && file_exists('../uploads/' . $foto_lama)) {
                unlink('../uploads/' . $foto_lama);
            }
        }
    }

    $query = "UPDATE produk SET 
                id_kategori = '$id_kategori', 
                nama_produk = '$nama_produk', 
                deskripsi = '$deskripsi', 
                harga = $harga, 
                stok = $stok, 
                foto = '$foto_nama' 
              WHERE id_produk = '$id_produk'";
    
    mysqli_query($koneksi, $query);
    header('Location: produk.php');
    exit;
}

// 3. DELETE (Hapus Produk + Hapus File Foto)
if (isset($_GET['hapus'])) {
    $id_produk = mysqli_real_escape_string($koneksi, $_GET['hapus']);

    // Ambil nama foto sebelum hapus record
    $get_foto = mysqli_query($koneksi, "SELECT foto FROM produk WHERE id_produk = '$id_produk'");
    $data_foto = mysqli_fetch_assoc($get_foto);

    if ($data_foto) {
        $file_foto = $data_foto['foto'];
        if ($file_foto != 'default.jpg' && file_exists('../uploads/' . $file_foto)) {
            unlink('../uploads/' . $file_foto); // Hapus foto dari server
        }
    }

    mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk = '$id_produk'");
    header('Location: produk.php');
    exit;
}

// 4. READ (Ambil Data Produk & Kategori)
$produk_list   = mysqli_query($koneksi, "SELECT produk.*, kategori.nama_kategori FROM produk JOIN kategori ON produk.id_kategori = kategori.id_kategori ORDER BY produk.id_produk DESC");
$kategori_list = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk - Marketplace</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #474a4e 0%, #959698 100%);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin-bottom: 5px;
            transition: all 0.2s ease;
        }

        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.15);
            font-weight: 600;
        }

        /* Main Content Styling */
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .btn-custom-primary {
            background-color: #525458;
            border: none;
            color: white;
            transition: all 0.2s;
        }

        .btn-custom-primary:hover {
            background-color: #575758;
            color: white;
        }

        .img-preview {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
        }

        @media (max-width: 991px) {
            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar Navigation -->
    <div class="sidebar text-white p-3 shadow-sm d-flex flex-column justify-content-between">
        <div>
            <!-- Brand Name -->
            <div class="d-flex align-items-center mb-3 px-2">
                <div class="bg-white text-primary rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                    <i class="bi bi-shop fs-5"></i>
                </div>
                <div>
                    <h5 class="fw-bold mb-0">Marketplace</h5>
                    <small class="text-white-50">Panel Admin</small>
                </div>
            </div>
            
            <hr class="border-light opacity-25">
            
            <!-- Info Admin -->
            <div class="mb-3 px-2">
                <small class="text-uppercase text-white-50 fw-bold" style="font-size: 11px;">Pengguna Aktif</small>
                <div class="d-flex align-items-center mt-2">
                    <i class="bi bi-person-circle fs-4 me-2 text-white"></i>
                    <span class="fw-semibold text-truncate"><?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?></span>
                </div>
            </div>
            
            <hr class="border-light opacity-25">

            <!-- Navigation Links -->
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="kategori.php" class="nav-link">
                        <i class="bi bi-tags me-2"></i> Kategori Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="produk.php" class="nav-link active">
                        <i class="bi bi-box-seam me-2"></i> Data Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="pesanan.php" class="nav-link">
                        <i class="bi bi-cart-check me-2"></i> Daftar Pesanan
                    </a>
                </li>
            </ul>
        </div>

        <!-- Tombol Logout -->
        <div class="pt-3 border-top border-light opacity-25 mt-auto">
            <a href="../logout.php" class="btn btn-outline-light w-100 rounded-3" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                <i class="bi bi-box-arrow-left me-1"></i> Keluar
            </a>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="main-content w-100">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Manajemen Produk</h3>
                <p class="text-muted small mb-0">Kelola katalog produk, harga, stok, dan foto Marketplace</p>
            </div>
            <a href="../index.php" target="_blank" class="btn btn-outline-primary rounded-3 px-3 shadow-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i> Lihat Toko Utama
            </a>
        </div>

        <!-- Form Tambah Produk (CREATE) -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3 border-bottom-0">
                <h6 class="fw-bold mb-0 text-dark">
                    <i class="bi bi-plus-circle text-primary me-2"></i>Tambah Produk Baru
                </h6>
            </div>
            <div class="card-body pt-0">
                <form method="POST" action="" enctype="multipart/form-data" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-medium small text-secondary">Nama Produk</label>
                        <input type="text" name="nama_produk" class="form-control rounded-3" placeholder="Contoh: Baju Kemeja" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-medium small text-secondary">Kategori</label>
                        <select name="id_kategori" class="form-select rounded-3" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php 
                            mysqli_data_seek($kategori_list, 0);
                            while($k = mysqli_fetch_assoc($kategori_list)): 
                            ?>
                                <option value="<?= $k['id_kategori']; ?>"><?= htmlspecialchars($k['nama_kategori']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-medium small text-secondary">Harga (Rp)</label>
                        <input type="number" name="harga" class="form-control rounded-3" placeholder="150000" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-medium small text-secondary">Stok Awal</label>
                        <input type="number" name="stok" class="form-control rounded-3" placeholder="10" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-medium small text-secondary">Foto Produk</label>
                        <input type="file" name="foto" class="form-control rounded-3" accept="image/*">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label fw-medium small text-secondary">Deskripsi Produk</label>
                        <textarea name="deskripsi" class="form-control rounded-3" rows="2" placeholder="Tulis deskripsi rinci produk..."></textarea>
                    </div>
                    <div class="col-12 text-end">
                        <button type="submit" name="tambah_produk" class="btn btn-custom-primary fw-medium px-4 py-2 rounded-3">
                            <i class="bi bi-save me-1"></i> Simpan Produk
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tabel Daftar Produk (READ, UPDATE, DELETE) -->
        <div class="card">
            <div class="card-header bg-white py-3 border-bottom-0">
                <h6 class="fw-bold mb-0 text-dark">
                    <i class="bi bi-box text-primary me-2"></i>Daftar Produk
                </h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Foto</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Stok</th>
                                <th class="text-end pe-4">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($produk_list) > 0): ?>
                                <?php while ($p = mysqli_fetch_assoc($produk_list)): ?>
                                <tr>
                                    <td class="ps-4">
                                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-2">
                                            <?= $p['id_produk']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <img src="../uploads/<?= $p['foto']; ?>" class="img-preview border shadow-sm" onerror="this.src='https://via.placeholder.com/50?text=No+Img'">
                                    </td>
                                    <td class="fw-medium text-dark"><?= htmlspecialchars($p['nama_produk']); ?></td>
                                    <td><span class="badge bg-secondary rounded-2"><?= htmlspecialchars($p['nama_kategori']); ?></span></td>
                                    <td class="fw-semibold text-success">Rp <?= number_format($p['harga'], 0, ',', '.'); ?></td>
                                    <td><?= $p['stok']; ?> pcs</td>
                                    <td class="text-end pe-4">
                                        <!-- Tombol Edit Modal -->
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-primary rounded-3 me-1" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalEditProd<?= $p['id_produk']; ?>">
                                            <i class="bi bi-pencil me-1"></i> Edit
                                        </button>

                                        <!-- Tombol Hapus -->
                                        <a href="produk.php?hapus=<?= $p['id_produk']; ?>" 
                                           class="btn btn-sm btn-outline-danger rounded-3" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini beserta fotonya?')">
                                            <i class="bi bi-trash me-1"></i> Hapus
                                        </a>
                                    </td>
                                </tr>

                                <!-- MODAL EDIT PRODUK (UPDATE) -->
                                <div class="modal fade" id="modalEditProd<?= $p['id_produk']; ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content border-0 rounded-4 shadow">
                                            <div class="modal-header border-0 pb-0">
                                                <h5 class="modal-title fw-bold text-dark">
                                                    <i class="bi bi-pencil-square text-warning me-2"></i>Edit Produk - <?= $p['id_produk']; ?>
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form method="POST" action="" enctype="multipart/form-data">
                                                <div class="modal-body">
                                                    <input type="hidden" name="id_produk" value="<?= $p['id_produk']; ?>">
                                                    <input type="hidden" name="foto_lama" value="<?= $p['foto']; ?>">

                                                    <div class="row g-3">
                                                        <div class="col-md-6">
                                                            <label class="form-label fw-medium small text-secondary">Nama Produk</label>
                                                            <input type="text" name="nama_produk" class="form-control rounded-3" value="<?= htmlspecialchars($p['nama_produk']); ?>" required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label fw-medium small text-secondary">Kategori</label>
                                                            <select name="id_kategori" class="form-select rounded-3" required>
                                                                <?php 
                                                                mysqli_data_seek($kategori_list, 0);
                                                                while($k = mysqli_fetch_assoc($kategori_list)): 
                                                                ?>
                                                                    <option value="<?= $k['id_kategori']; ?>" <?= ($k['id_kategori'] == $p['id_kategori']) ? 'selected' : ''; ?>>
                                                                        <?= htmlspecialchars($k['nama_kategori']); ?>
                                                                    </option>
                                                                <?php endwhile; ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label fw-medium small text-secondary">Harga (Rp)</label>
                                                            <input type="number" name="harga" class="form-control rounded-3" value="<?= $p['harga']; ?>" required>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label fw-medium small text-secondary">Stok</label>
                                                            <input type="number" name="stok" class="form-control rounded-3" value="<?= $p['stok']; ?>" required>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label fw-medium small text-secondary">Ganti Foto (Opsional)</label>
                                                            <input type="file" name="foto" class="form-control rounded-3" accept="image/*">
                                                        </div>
                                                        <div class="col-md-12">
                                                            <label class="form-label fw-medium small text-secondary d-block">Foto Saat Ini</label>
                                                            <img src="../uploads/<?= $p['foto']; ?>" class="rounded-3 border shadow-sm mb-2" style="width: 80px; height: 80px; object-fit: cover;">
                                                        </div>
                                                        <div class="col-md-12">
                                                            <label class="form-label fw-medium small text-secondary">Deskripsi</label>
                                                            <textarea name="deskripsi" class="form-control rounded-3" rows="3"><?= htmlspecialchars($p['deskripsi']); ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-0 pt-0">
                                                    <button type="button" class="btn btn-light rounded-3 px-3" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" name="update_produk" class="btn btn-primary rounded-3 px-4">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL EDIT PRODUK -->

                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                        Belum ada produk yang ditambahkan.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>