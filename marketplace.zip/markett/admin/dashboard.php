<?php
// admin/dashboard.php - Halaman Utama Admin Marketplace
require_once '../config.php';

// Cek Keamanan Session Login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

// 1. Hitung Total Produk
$q_produk = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk");
$total_produk = mysqli_fetch_assoc($q_produk)['total'];

// 2. Hitung Total Kategori
$q_kategori = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kategori");
$total_kategori = mysqli_fetch_assoc($q_kategori)['total'];

// 3. Hitung Total Pesanan
$q_pesanan = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pesanan");
$total_pesanan = mysqli_fetch_assoc($q_pesanan)['total'];

// 4. Ambil 5 Pesanan Terbaru
$q_terbaru = mysqli_query($koneksi, "
    SELECT pesanan.*, produk.nama_produk 
    FROM pesanan 
    LEFT JOIN produk ON pesanan.id_produk = produk.id_produk 
    ORDER BY pesanan.id_pesanan DESC LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Marketplace</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar Styling (Disamakan dengan Kategori) */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #515357 0%, #2e3137 100%);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin-bottom: 5px;
            transition: all 0.2s ease;
        }

        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.15);
            font-weight: 600;
        }

        /* Main Content Styling */
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .card-stat {
            border: none;
            border-radius: 16px;
            transition: transform 0.2s ease;
        }

        .card-stat:hover {
            transform: translateY(-4px);
        }

        @media (max-width: 991px) {
            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar Navigation -->
    <div class="sidebar text-white p-3 shadow-sm d-flex flex-column justify-content-between">
        <div>
            <!-- Brand Name -->
            <div class="d-flex align-items-center mb-3 px-2">
                <div class="bg-white text-primary rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                    <i class="bi bi-shop fs-5"></i>
                </div>
                <div>
                    <h5 class="fw-bold mb-0">Marketplace</h5>
                    <small class="text-white-50">Panel Admin</small>
                </div>
            </div>
            
            <hr class="border-light opacity-25">
            
            <!-- Info Admin -->
            <div class="mb-3 px-2">
                <small class="text-uppercase text-white-50 fw-bold" style="font-size: 11px;">Pengguna Aktif</small>
                <div class="d-flex align-items-center mt-2">
                    <i class="bi bi-person-circle fs-4 me-2 text-white"></i>
                    <span class="fw-semibold text-truncate"><?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?></span>
                </div>
            </div>
            
            <hr class="border-light opacity-25">

            <!-- Navigation Links -->
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link active">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="kategori.php" class="nav-link">
                        <i class="bi bi-tags me-2"></i> Kategori Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="produk.php" class="nav-link">
                        <i class="bi bi-box-seam me-2"></i> Data Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="pesanan.php" class="nav-link">
                        <i class="bi bi-cart-check me-2"></i> Daftar Pesanan
                    </a>
                </li>
            </ul>
        </div>

        <!-- Tombol Logout -->
        <div class="pt-3 border-top border-light opacity-25 mt-auto">
            <a href="../logout.php" class="btn btn-outline-light w-100 rounded-3" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                <i class="bi bi-box-arrow-left me-1"></i> Keluar
            </a>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="main-content w-100">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Dashboard Overview</h3>
                <p class="text-muted small mb-0">Selamat datang kembali, <strong><?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?></strong>!</p>
            </div>
            <a href="../index.php" target="_blank" class="btn btn-outline-primary rounded-3 px-3 shadow-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i> Lihat Toko Utama
            </a>
        </div>

        <!-- Cards Stat Summary -->
        <div class="row g-4 mb-4">
            <!-- Total Produk -->
            <div class="col-md-4">
                <div class="card card-stat bg-primary text-white p-3">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 fw-semibold text-uppercase mb-2" style="font-size: 12px;">Total Produk</h6>
                            <h2 class="display-6 fw-bold mb-0"><?= $total_produk; ?></h2>
                        </div>
                        <i class="bi bi-box-seam display-5 opacity-50"></i>
                    </div>
                    <div class="card-footer bg-transparent border-0 pt-0 text-end">
                        <a href="produk.php" class="text-white text-decoration-none small fw-medium">Kelola Produk <i class="bi bi-arrow-right ms-1"></i></a>
                    </div>
                </div>
            </div>

            <!-- Total Kategori -->
            <div class="col-md-4">
                <div class="card card-stat bg-success text-white p-3">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 fw-semibold text-uppercase mb-2" style="font-size: 12px;">Total Kategori</h6>
                            <h2 class="display-6 fw-bold mb-0"><?= $total_kategori; ?></h2>
                        </div>
                        <i class="bi bi-tags display-5 opacity-50"></i>
                    </div>
                    <div class="card-footer bg-transparent border-0 pt-0 text-end">
                        <a href="kategori.php" class="text-white text-decoration-none small fw-medium">Kelola Kategori <i class="bi bi-arrow-right ms-1"></i></a>
                    </div>
                </div>
            </div>

            <!-- Total Pesanan -->
            <div class="col-md-4">
                <div class="card card-stat bg-warning text-dark p-3">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-dark-50 fw-semibold text-uppercase mb-2" style="font-size: 12px;">Total Pesanan</h6>
                            <h2 class="display-6 fw-bold mb-0"><?= $total_pesanan; ?></h2>
                        </div>
                        <i class="bi bi-cart-check display-5 opacity-50"></i>
                    </div>
                    <div class="card-footer bg-transparent border-0 pt-0 text-end">
                        <a href="pesanan.php" class="text-dark text-decoration-none small fw-medium">Lihat Pesanan <i class="bi bi-arrow-right ms-1"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabel 5 Pesanan Terakhir -->
        <div class="card">
            <div class="card-header bg-white py-3 border-bottom-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0 text-dark">
                    <i class="bi bi-clock-history text-primary me-2"></i>5 Pesanan Masuk Terbaru
                </h6>
                <a href="pesanan.php" class="btn btn-sm btn-outline-primary rounded-3">Lihat Selengkapnya</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">ID Transaksi</th>
                                <th>Pembeli</th>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Total Harga</th>
                                <th class="text-end pe-4">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($q_terbaru) > 0): ?>
                                <?php while($p = mysqli_fetch_assoc($q_terbaru)): ?>
                                    <tr>
                                        <td class="ps-4">
                                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-2">
                                                <?= $p['id_pesanan']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="fw-medium text-dark"><?= htmlspecialchars($p['nama_pembeli']); ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($p['nomor_hp']); ?></small>
                                        </td>
                                        <td class="text-secondary"><?= htmlspecialchars($p['nama_produk'] ?? 'Produk Dihapus'); ?></td>
                                        <td><?= $p['jumlah']; ?> pcs</td>
                                        <td class="fw-semibold text-dark">Rp <?= number_format($p['total_harga'], 0, ',', '.'); ?></td>
                                        <td class="text-end pe-4">
                                            <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-2 py-1 rounded-2">
                                                <?= $p['status'] ?? 'Pending'; ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">
                                        <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                        Belum ada transaksi pesanan masuk.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>