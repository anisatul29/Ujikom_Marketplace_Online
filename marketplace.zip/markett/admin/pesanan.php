<?php
// admin/pesanan.php - Kelola Pesanan Masuk Marketplace
require_once '../config.php';

// Cek autentikasi admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

// 1. UPDATE STATUS PESANAN
if (isset($_POST['update_status'])) {
    $id_pesanan = mysqli_real_escape_string($koneksi, $_POST['id_pesanan']);
    $status     = mysqli_real_escape_string($koneksi, $_POST['status']);

    mysqli_query($koneksi, "UPDATE pesanan SET status = '$status' WHERE id_pesanan = '$id_pesanan'");
    header('Location: pesanan.php');
    exit;
}

// 2. DELETE PESANAN (Hapus Transaksi)
if (isset($_GET['hapus'])) {
    $id_pesanan = mysqli_real_escape_string($koneksi, $_GET['hapus']);
    mysqli_query($koneksi, "DELETE FROM pesanan WHERE id_pesanan = '$id_pesanan'");
    header('Location: pesanan.php');
    exit;
}

// 3. READ ALL PESANAN
$pesanan_list = mysqli_query($koneksi, "SELECT pesanan.*, produk.nama_produk, produk.harga 
                                        FROM pesanan 
                                        JOIN produk ON pesanan.id_produk = produk.id_produk 
                                        ORDER BY pesanan.id_pesanan DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan - Marketplace</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #919498 0%, #37393c 100%);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin-bottom: 5px;
            transition: all 0.2s ease;
        }

        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.15);
            font-weight: 600;
        }

        /* Main Content Styling */
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .btn-custom-primary {
            background-color: #55595e;
            border: none;
            color: white;
            transition: all 0.2s;
        }

        .btn-custom-primary:hover {
            background-color: #70757c;
            color: white;
        }

        @media (max-width: 991px) {
            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar Navigation -->
    <div class="sidebar text-white p-3 shadow-sm d-flex flex-column justify-content-between">
        <div>
            <!-- Brand Name -->
            <div class="d-flex align-items-center mb-3 px-2">
                <div class="bg-white text-primary rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                    <i class="bi bi-shop fs-5"></i>
                </div>
                <div>
                    <h5 class="fw-bold mb-0">Marketplace</h5>
                    <small class="text-white-50">Panel Admin</small>
                </div>
            </div>
            
            <hr class="border-light opacity-25">
            
            <!-- Info Admin -->
            <div class="mb-3 px-2">
                <small class="text-uppercase text-white-50 fw-bold" style="font-size: 11px;">Pengguna Aktif</small>
                <div class="d-flex align-items-center mt-2">
                    <i class="bi bi-person-circle fs-4 me-2 text-white"></i>
                    <span class="fw-semibold text-truncate"><?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?></span>
                </div>
            </div>
            
            <hr class="border-light opacity-25">

            <!-- Navigation Links -->
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="kategori.php" class="nav-link">
                        <i class="bi bi-tags me-2"></i> Kategori Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="produk.php" class="nav-link">
                        <i class="bi bi-box-seam me-2"></i> Data Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="pesanan.php" class="nav-link active">
                        <i class="bi bi-cart-check me-2"></i> Daftar Pesanan
                    </a>
                </li>
            </ul>
        </div>

        <!-- Tombol Logout -->
        <div class="pt-3 border-top border-light opacity-25 mt-auto">
            <a href="../logout.php" class="btn btn-outline-light w-100 rounded-3" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                <i class="bi bi-box-arrow-left me-1"></i> Keluar
            </a>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="main-content w-100">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Daftar Pesanan Masuk</h3>
                <p class="text-muted small mb-0">Kelola transaksi dan hubungan pelanggan Marketplace</p>
            </div>
            <a href="../index.php" target="_blank" class="btn btn-outline-primary rounded-3 px-3 shadow-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i> Lihat Toko Utama
            </a>
        </div>

        <!-- Tabel Daftar Pesanan -->
        <div class="card">
            <div class="card-header bg-white py-3 border-bottom-0">
                <h6 class="fw-bold mb-0 text-dark">
                    <i class="bi bi-cart-fill text-primary me-2"></i>Data Transaksi Pesanan
                </h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">ID TRX</th>
                                <th>Tanggal</th>
                                <th>Pembeli & Kontak</th>
                                <th>Produk Dipesan</th>
                                <th>Jumlah</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($pesanan_list) > 0): ?>
                                <?php while ($ord = mysqli_fetch_assoc($pesanan_list)): ?>
                                <tr>
                                    <td class="ps-4">
                                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-2">
                                            <?= $ord['id_pesanan']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?= date('d/m/Y H:i', strtotime($ord['tanggal_pesan'])); ?></small>
                                    </td>
                                    <td>
                                        <strong class="text-dark d-block"><?= htmlspecialchars($ord['nama_pembeli']); ?></strong>
                                        <!-- Tombol Direct WhatsApp -->
                                        <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $ord['nomor_hp']); ?>?text=Halo%20<?= urlencode($ord['nama_pembeli']); ?>,%20kami%20dari%20Toko%20Mila%20terkait%20pesanan%20<?= $ord['id_pesanan']; ?>" 
                                           target="_blank" class="badge bg-success-subtle text-success text-decoration-none mt-1">
                                            <i class="bi bi-whatsapp me-1"></i><?= htmlspecialchars($ord['nomor_hp']); ?>
                                        </a>
                                    </td>
                                    <td class="fw-medium text-dark"><?= htmlspecialchars($ord['nama_produk']); ?></td>
                                    <td><span class="badge bg-secondary rounded-2"><?= $ord['jumlah']; ?> pcs</span></td>
                                    <td class="fw-semibold text-danger">Rp <?= number_format($ord['total_harga'], 0, ',', '.'); ?></td>
                                    <td>
                                        <?php 
                                            $status = isset($ord['status']) ? $ord['status'] : 'Pending';
                                            $badge_color = 'bg-warning text-dark';
                                            if ($status == 'Diproses') $badge_color = 'bg-info text-dark';
                                            if ($status == 'Selesai')  $badge_color = 'bg-success text-white';
                                            if ($status == 'Dibatalkan') $badge_color = 'bg-danger text-white';
                                        ?>
                                        <span class="badge <?= $badge_color; ?> rounded-2 px-2 py-1"><?= $status; ?></span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <!-- Tombol Edit Status Modal -->
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-primary rounded-3 me-1" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalStatus<?= $ord['id_pesanan']; ?>">
                                            <i class="bi bi-pencil me-1"></i> Status
                                        </button>

                                        <!-- Hapus Transaksi -->
                                        <a href="pesanan.php?hapus=<?= $ord['id_pesanan']; ?>" 
                                           class="btn btn-sm btn-outline-danger rounded-3" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus data pesanan ini?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- MODAL UBAH STATUS PESANAN -->
                                <div class="modal fade" id="modalStatus<?= $ord['id_pesanan']; ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content border-0 rounded-4 shadow">
                                            <div class="modal-header border-0 pb-0">
                                                <h5 class="modal-title fw-bold text-dark">
                                                    <i class="bi bi-arrow-repeat text-primary me-2"></i>Ubah Status Transaksi
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form method="POST" action="">
                                                <div class="modal-body">
                                                    <input type="hidden" name="id_pesanan" value="<?= $ord['id_pesanan']; ?>">
                                                    <div class="bg-light p-3 rounded-3 mb-3">
                                                        <p class="mb-1 small text-muted">ID Pesanan: <strong class="text-dark"><?= $ord['id_pesanan']; ?></strong></p>
                                                        <p class="mb-0 small text-muted">Pembeli: <strong class="text-dark"><?= htmlspecialchars($ord['nama_pembeli']); ?></strong></p>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label fw-medium small text-secondary">Pilih Status Baru</label>
                                                        <select name="status" class="form-select rounded-3">
                                                            <option value="Pending" <?= ($status == 'Pending') ? 'selected' : ''; ?>>Pending (Menunggu)</option>
                                                            <option value="Diproses" <?= ($status == 'Diproses') ? 'selected' : ''; ?>>Diproses (Dikemas/Dikirim)</option>
                                                            <option value="Selesai" <?= ($status == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                                                            <option value="Dibatalkan" <?= ($status == 'Dibatalkan') ? 'selected' : ''; ?>>Dibatalkan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-0 pt-0">
                                                    <button type="button" class="btn btn-light rounded-3 px-3" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" name="update_status" class="btn btn-primary rounded-3 px-4">Simpan Status</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL STATUS -->

                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                        Belum ada data pesanan masuk.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>