<?php
// admin/kategori.php - CRUD Kategori Produk arketplace
require_once '../config.php';

// Cek autentikasi admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

// 1. CREATE (Tambah Kategori)
if (isset($_POST['tambah_kategori'])) {
    $id_kategori   = generateID($koneksi, 'kategori', 'id_kategori', 'KAT');
    $nama_kategori = mysqli_real_escape_string($koneksi, $_POST['nama_kategori']);

    if (!empty($nama_kategori)) {
        mysqli_query($koneksi, "INSERT INTO kategori (id_kategori, nama_kategori) VALUES ('$id_kategori', '$nama_kategori')");
        header('Location: kategori.php');
        exit;
    }
}

// 2. UPDATE (Edit Kategori)
if (isset($_POST['update_kategori'])) {
    $id_kategori   = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $nama_kategori = mysqli_real_escape_string($koneksi, $_POST['nama_kategori']);

    if (!empty($nama_kategori)) {
        mysqli_query($koneksi, "UPDATE kategori SET nama_kategori = '$nama_kategori' WHERE id_kategori = '$id_kategori'");
        header('Location: kategori.php');
        exit;
    }
}

// 3. DELETE (Hapus Kategori)
if (isset($_GET['hapus'])) {
    $id_kategori = mysqli_real_escape_string($koneksi, $_GET['hapus']);
    mysqli_query($koneksi, "DELETE FROM kategori WHERE id_kategori = '$id_kategori'");
    header('Location: kategori.php');
    exit;
}

// 4. READ (Ambil Semua Kategori)
$kategori_list = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id_kategori DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kategori - Toko Mila</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar Styling (Disamakan persis dengan Dashboard) */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #85888c 0%, #424448 100%);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin-bottom: 5px;
            transition: all 0.2s ease;
        }

        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.15);
            font-weight: 600;
        }

        /* Main Content Styling */
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .btn-custom-primary {
            background-color: #56585a;
            border: none;
            color: white;
            transition: all 0.2s;
        }

        .btn-custom-primary:hover {
            background-color: #56585c;
            color: white;
        }

        @media (max-width: 991px) {
            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar Navigation -->
    <div class="sidebar text-white p-3 shadow-sm d-flex flex-column justify-content-between">
        <div>
            <!-- Brand Name -->
            <div class="d-flex align-items-center mb-3 px-2">
                <div class="bg-white text-primary rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                    <i class="bi bi-shop fs-5"></i>
                </div>
                <div>
                    <h5 class="fw-bold mb-0">Marketplace</h5>
                    <small class="text-white-50">Panel Admin</small>
                </div>
            </div>
            
            <hr class="border-light opacity-25">
            
            <!-- Info Admin -->
            <div class="mb-3 px-2">
                <small class="text-uppercase text-white-50 fw-bold" style="font-size: 11px;">Pengguna Aktif</small>
                <div class="d-flex align-items-center mt-2">
                    <i class="bi bi-person-circle fs-4 me-2 text-white"></i>
                    <span class="fw-semibold text-truncate"><?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?></span>
                </div>
            </div>
            
            <hr class="border-light opacity-25">

            <!-- Navigation Links -->
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="kategori.php" class="nav-link active">
                        <i class="bi bi-tags me-2"></i> Kategori Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="produk.php" class="nav-link">
                        <i class="bi bi-box-seam me-2"></i> Data Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a href="pesanan.php" class="nav-link">
                        <i class="bi bi-cart-check me-2"></i> Daftar Pesanan
                    </a>
                </li>
            </ul>
        </div>

        <!-- Tombol Logout -->
        <div class="pt-3 border-top border-light opacity-25 mt-auto">
            <a href="../logout.php" class="btn btn-outline-light w-100 rounded-3" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                <i class="bi bi-box-arrow-left me-1"></i> Keluar
            </a>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="main-content w-100">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Manajemen Kategori</h3>
                <p class="text-muted small mb-0">Kelola daftar kategori produk untuk sistem Toko Mila</p>
            </div>
            <a href="../index.php" target="_blank" class="btn btn-outline-primary rounded-3 px-3 shadow-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i> Lihat Toko Utama
            </a>
        </div>

        <div class="row g-4">
            <!-- Form Tambah Kategori (CREATE) -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header bg-white py-3 border-bottom-0">
                        <h6 class="fw-bold mb-0 text-dark">
                            <i class="bi bi-plus-circle text-primary me-2"></i>Tambah Kategori
                        </h6>
                    </div>
                    <div class="card-body pt-0">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label fw-medium small text-secondary">Nama Kategori</label>
                                <input type="text" name="nama_kategori" class="form-control rounded-3" placeholder="Contoh: Pakaian Wanita" required>
                            </div>
                            <button type="submit" name="tambah_kategori" class="btn btn-custom-primary w-100 fw-medium py-2 rounded-3">
                                <i class="bi bi-save me-1"></i> Simpan Kategori
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Tabel Daftar Kategori (READ, UPDATE, DELETE) -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header bg-white py-3 border-bottom-0">
                        <h6 class="fw-bold mb-0 text-dark">
                            <i class="bi bi-list-stars text-primary me-2"></i>Daftar Kategori Produk
                        </h6>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">ID Kategori</th>
                                        <th>Nama Kategori</th>
                                        <th class="text-end pe-4">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (mysqli_num_rows($kategori_list) > 0): ?>
                                        <?php while ($kat = mysqli_fetch_assoc($kategori_list)): ?>
                                        <tr>
                                            <td class="ps-4">
                                                <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-2">
                                                    <?= $kat['id_kategori']; ?>
                                                </span>
                                            </td>
                                            <td class="fw-medium text-dark"><?= htmlspecialchars($kat['nama_kategori']); ?></td>
                                            <td class="text-end pe-4">
                                                <!-- Tombol Edit Modal -->
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-primary rounded-3 me-1" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#modalEdit<?= $kat['id_kategori']; ?>">
                                                    <i class="bi bi-pencil me-1"></i> Edit
                                                </button>

                                                <!-- Tombol Hapus -->
                                                <a href="kategori.php?hapus=<?= $kat['id_kategori']; ?>" 
                                                   class="btn btn-sm btn-outline-danger rounded-3" 
                                                   onclick="return confirm('Apakah Anda yakin ingin menghapus kategori ini?')">
                                                    <i class="bi bi-trash me-1"></i> Hapus
                                                </a>
                                            </td>
                                        </tr>

                                        <!-- MODAL EDIT KATEGORI (UPDATE) -->
                                        <div class="modal fade" id="modalEdit<?= $kat['id_kategori']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content border-0 rounded-4 shadow">
                                                    <div class="modal-header border-0 pb-0">
                                                        <h5 class="modal-title fw-bold text-dark">
                                                            <i class="bi bi-pencil-square text-warning me-2"></i>Edit Kategori
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form method="POST" action="">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id_kategori" value="<?= $kat['id_kategori']; ?>">
                                                            
                                                            <div class="mb-3">
                                                                <label class="form-label fw-medium small text-secondary">ID Kategori</label>
                                                                <input type="text" class="form-control bg-light rounded-3" value="<?= $kat['id_kategori']; ?>" disabled>
                                                            </div>
                                                            
                                                            <div class="mb-3">
                                                                <label class="form-label fw-medium small text-secondary">Nama Kategori</label>
                                                                <input type="text" name="nama_kategori" class="form-control rounded-3" value="<?= htmlspecialchars($kat['nama_kategori']); ?>" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer border-0 pt-0">
                                                            <button type="button" class="btn btn-light rounded-3 px-3" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" name="update_kategori" class="btn btn-primary rounded-3 px-4">Simpan Perubahan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END MODAL EDIT -->

                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center text-muted py-4">
                                                <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                                                Belum ada kategori yang ditambahkan.
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>