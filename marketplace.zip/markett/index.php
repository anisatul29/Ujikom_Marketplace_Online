<?php
// index.php - Landing Page Utama Marketplace
require_once 'config.php';

// Ambil input pencarian & filter kategori
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';
$kategori_filter = isset($_GET['kategori']) ? mysqli_real_escape_string($koneksi, $_GET['kategori']) : '';

// Query dasar pengambilan produk
$query = "SELECT produk.*, kategori.nama_kategori FROM produk JOIN kategori ON produk.id_kategori = kategori.id_kategori WHERE 1=1";

if (!empty($search)) {
    $query .= " AND produk.nama_produk LIKE '%$search%'";
}

if (!empty($kategori_filter)) {
    $query .= " AND produk.id_kategori = '$kategori_filter'";
}

$query .= " ORDER BY produk.id_produk DESC";
$result = mysqli_query($koneksi, $query);
$kategori_result = mysqli_query($koneksi, "SELECT * FROM kategori");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace - Belanja Online Mudah, Cepat & Terpercaya</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
            color: #333;
        }

        /* Hero Banner Premium */
        .hero-banner {
        background: linear-gradient(135deg, #71757b, #8a8a8a, #d6d6d6);
        color: white;
        }
            padding: 70px 0 90px;
            border-radius: 0 0 35px 35px;
            box-shadow: 0 10px 30px rgba(13, 110, 253, 0.2);
        }

        /* Search Box Floating */
        .search-box-wrapper {
            margin-top: -50px;
            z-index: 10;
            position: relative;
        }

        /* Product Card Styling */
        .product-card {
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            border: none;
            border-radius: 18px;
            overflow: hidden;
            background: #f4f1f1e0;
        }
        .product-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1) !important;
        }

        /* Image Wrapper & Badges */
        .img-container {
            position: relative;
            overflow: hidden;
            background-color: #f8f9fa;
        }
        .product-img {
            height: 240px;
            object-fit: cover;
            width: 100%;
            transition: transform 0.5s ease;
        }
        .product-card:hover .product-img {
            transform: scale(1.05);
        }

       .badge-category {
    position: absolute;
    top: 12px;
    left: 12px;
    background: #6c757d;
    backdrop-filter: blur(8px);
    color: #fff;
    font-size: 0.75rem;
    font-weight: 600;
    padding: 6px 12px;
    border-radius: 20px;
    letter-spacing: 0.5px;
}

        /* Stock Status Pill */
        .badge-stok {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 12px;
        }

        /* Custom Button */
        .btn-custom-buy {
            background: #a0a4aa;
            color: #fbf8f8;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        .btn-custom-buy:hover {
            background: #9fa6b1;
            color: #fff;
            box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3);
        }
    </style>
</head>
<body>

<!-- Navbar Marketplace -->
<nav class="navbar navbar-expand-lg navbar-light sticky-top shadow-sm py-3"
     style="background:linear-gradient(90deg,#ffffff 0%, #888a8d 40%, #d6d6d6 100%);
            border-bottom:1px solid #b2b5b8;">
  <div class="container">
    <a class="navbar-brand fw-bold fs-4 d-flex align-items-center" href="index.php">
        <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 38px; height: 38px;">
            <i class="bi bi-bag-heart-fill fs-5"></i>
        </div>
        Marketplace
    </a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-2 mt-3 mt-lg-0">
        <li class="nav-item">
          <a class="nav-link active px-3" href="index.php"><i class="bi bi-house-door me-1"></i>Beranda</a>
        </li>
        <li class="nav-item">
          <a href="login.php" class="btn btn-light text-primary btn-sm fw-bold px-4 py-2 rounded-pill shadow-sm">
             <i class="bi bi-shield-lock-fill me-1"></i>Login Admin
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero / Header Section -->
<div class="hero-banner text-center">
    <div class="container px-4">
        <span class="badge bg-white text-primary fw-bold px-3 py-2 rounded-pill mb-3 shadow-sm">
            <i class="bi bi-stars text-warning me-1"></i> Katalog Resmi Produk
        </span>
        <h1 class="display-4 fw-extrabold mb-3">Belanja Mudah,
Cepat dan Terpercaaya
 di <span class="text-warning">Marketplace</span></h1>
        <p class="lead opacity-90 mx-auto" style="max-width: 650px;">
            Temukan berbagai produk terlengkap dengan harga terbaik
        </p>
    </div>
</div>

<div class="container">
    <!-- Section Pencarian & Filter Floating -->
    <div class="search-box-wrapper mb-5">
        <div class="card border-0 shadow-lg rounded-4 p-3 p-md-4 bg-white">
            <form method="GET" action="index.php" class="row g-3 align-items-center">
                <div class="col-lg-6 col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 ps-3"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control bg-light border-0 py-2" placeholder="Cari nama produk di Marketplace..." value="<?= htmlspecialchars($search); ?>">
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 ps-3"><i class="bi bi-grid text-muted"></i></span>
                        <select name="kategori" class="form-select bg-light border-0 py-2">
                            <option value="">-- Semua Kategori --</option>
                            <?php while($kat = mysqli_fetch_assoc($kategori_result)): ?>
                                <option value="<?= $kat['id_kategori']; ?>" <?= ($kategori_filter == $kat['id_kategori']) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($kat['nama_kategori']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3">
                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold rounded-3">
                        <i class="bi bi-funnel me-1"></i> Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Header Judul Katalog -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0 text-dark">Katalog Produk</h3>
            <small class="text-muted">Menampilkan produk pilihan terbaru dari Marketplace</small>
        </div>
        <?php if(!empty($search) || !empty($kategori_filter)): ?>
            <a href="index.php" class="btn btn-outline-secondary btn-sm rounded-pill">
                <i class="bi bi-arrow-counterclockwise me-1"></i> Reset Filter
            </a>
        <?php endif; ?>
    </div>

    <!-- Katalog Produk -->
    <div class="row">
        <?php if(mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                    <div class="card product-card h-100 shadow-sm">
                        <!-- Gambar Produk + Badge Kategori -->
                        <div class="img-container">
                            <span class="badge badge-category shadow-sm">
                                <?= htmlspecialchars($row['nama_kategori']); ?>
                            </span>
                            <img src="uploads/<?= $row['foto']; ?>" class="product-img" alt="<?= htmlspecialchars($row['nama_produk']); ?>" onerror="this.src='https://via.placeholder.com/300x200?text=Toko+Mila'">
                        </div>
                        
                        <!-- Detail Produk -->
                        <div class="card-body d-flex flex-column p-4">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="badge bg-light text-secondary border fs- tiny"><?= $row['id_produk']; ?></span>
                                <?php if($row['stok'] > 0): ?>
                                    <span class="badge badge-stok bg-success-subtle text-success fw-semibold">
                                        <i class="bi bi-check-circle me-1"></i>Stok: <?= $row['stok']; ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge badge-stok bg-danger-subtle text-danger fw-semibold">
                                        Stok Habis
                                    </span>
                                <?php endif; ?>
                            </div>

                            <h5 class="card-title fw-bold text-dark mb-2 text-truncate" title="<?= htmlspecialchars($row['nama_produk']); ?>">
                                <?= htmlspecialchars($row['nama_produk']); ?>
                            </h5>
                            
                            <h4 class="text-primary fw-bold mb-3">
                                Rp <?= number_format($row['harga'], 0, ',', '.'); ?>
                            </h4>
                            
                            <a href="detail.php?id=<?= $row['id_produk']; ?>" class="btn btn-custom-buy mt-auto w-100 py-2">
                                <i class="bi bi-cart-plus me-1"></i> Detail & Pesan
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 my-4">
                <div class="card border-0 shadow-sm p-5 text-center rounded-4">
                    <i class="bi bi-box-seam display-1 text-muted opacity-50 mb-3"></i>
                    <h4 class="fw-bold">Produk Tidak Ditemukan</h4>
                    <p class="text-muted mb-3">Maaf, produk yang Anda cari belum tersedia di Marketplace.</p>
                    <div>
                        <a href="index.php" class="btn btn-primary rounded-pill px-4">
                            Lihat Semua Produk
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Footer Marketplace -->
<footer class="bg-white border-top py-4 mt-5">
    <div class="container text-center">
        <p class="mb-0 text-muted">&copy; <?= date('Y'); ?> <strong class="text-primary">Marketplace</strong>. Hak Cipta Dilindungi.</p>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>