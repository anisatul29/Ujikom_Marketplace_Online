<?php
// login.php - Halaman Login Admin Marketplace
require_once 'config.php';

$error = '';

if (isset($_POST['login'])) {
    $email    = mysqli_real_escape_string($koneksi, $_POST['email']);
    $password = $_POST['password'];

    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE email = '$email'");
    $admin = mysqli_fetch_assoc($query);

    if ($admin) {
        // Cek password (string biasa atau hashed password_verify)
        if ($password === $admin['password'] || password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_nama'] = $admin['nama'];
            
            // Berhasil login, arahkan ke dashboard
            header('Location: admin/dashboard.php');
            exit;
        } else {
            $error = 'Password yang Anda masukkan salah!';
        }
    } else {
        $error = 'Email admin tidak ditemukan!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Marketplace</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #acb5c1 0%, #444648 50%, #052c65 100%);
            min-height: 100vh;
        }

        .login-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            background: #ffffff;
        }

        .brand-icon {
            width: 60px;
            height: 60px;
            background-color: #e7f1ff;
            color: #bbc2cd;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .form-control:focus {
            border-color: #9fa6b0;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
        }

        .btn-login {
            background: #989ea6;
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            background: #a2aab6;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(90, 92, 95, 0.3);
        }
    </style>
</head>
<body class="d-flex align-items-center py-5">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-6 col-lg-4">
            <div class="card login-card p-3 p-md-4">
                <div class="card-body">
                    <!-- Brand / Header Logo -->
                    <div class="text-center mb-4">
                        <div class="brand-icon mb-3">
                            <i class="bi bi-shield-lock-fill fs-3"></i>
                        </div>
                        <h4 class="fw-bold text-dark mb-1">Login Admin</h4>
                        <p class="text-muted small">Panel Kelola Marketplace</p>
                    </div>

                    <!-- Alert Notifikasi Logout -->
                    <?php if (isset($_GET['status']) && $_GET['status'] == 'logout'): ?>
                        <div class="alert alert-success alert-dismissible fade show small py-2 rounded-3 mb-3" role="alert">
                            <i class="bi bi-check-circle-fill me-1"></i> Anda telah berhasil keluar.
                            <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Alert Pesan Error -->
                    <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show small py-2 rounded-3 mb-3" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-1"></i> <?= $error; ?>
                            <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Form Login -->
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label fw-medium small text-secondary">Email Admin</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control border-start-0 bg-light" required placeholder="admin@gmail.com">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-medium small text-secondary">Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-key"></i></span>
                                <input type="password" name="password" id="passwordInput" class="form-control border-start-0 border-end-0 bg-light" placeholder="••••••••" required>
                                <button class="btn btn-light border border-start-0 text-muted" type="button" id="togglePassword">
                                    <i class="bi bi-eye" id="eyeIcon"></i>
                                </button>
                            </div>
                            <div class="form-text mt-2 small">
                            </div>
                        </div>

                        <button type="submit" name="login" class="btn btn-primary btn-login w-100 text-white mt-3">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Masuk Sekarang
                        </button>
                    </form>

                    <!-- Tombol Kembali -->
                    <div class="text-center mt-4">
                        <a href="index.php" class="text-decoration-none small text-muted hover-primary">
                            <i class="bi bi-arrow-left me-1"></i> Kembali ke Beranda Toko
                        </a>
                    </div>
                </div>
            </div>

            <!-- Footer Hak Cipta Sederhana -->
            <div class="text-center mt-4 text-white-50 small">
                &copy; <?= date('Y'); ?> Toko Mila. All rights reserved.
            </div>
        </div>
    </div>
</div>

<!-- Script Intip Password -->
<script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('passwordInput');
    const eyeIcon = document.getElementById('eyeIcon');

    togglePassword.addEventListener('click', function () {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        
        eyeIcon.classList.toggle('bi-eye');
        eyeIcon.classList.toggle('bi-eye-slash');
    });
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>