<?php
// logout.php - Keluar dari Sesi Admin Marketplace
require_once 'config.php';

// 1. Hapus semua variabel session
$_SESSION = array();

// 2. Jika menggunakan cookie session, hapus cookie tersebut
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. Hancurkan seluruh session
session_destroy();

// 4. Alihkan pengguna kembali ke halaman login admin dengan status logout
header("Location: login.php?status=logout");
exit;
?>