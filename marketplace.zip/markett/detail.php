<?php
// detail.php - Halaman detail & order produk Marketplace
require_once 'config.php';

$id_produk = isset($_GET['id']) ? mysqli_real_escape_string($koneksi, $_GET['id']) : '';
$query = mysqli_query($koneksi, "SELECT produk.*, kategori.nama_kategori FROM produk JOIN kategori ON produk.id_kategori = kategori.id_kategori WHERE produk.id_produk = '$id_produk'");
$produk = mysqli_fetch_assoc($query);

if (!$produk) {
    header('Location: index.php');
    exit;
}

$pesan_status = '';

if (isset($_POST['submit_order'])) {
    $nama_pembeli = mysqli_real_escape_string($koneksi, $_POST['nama_pembeli']);
    $nomor_hp     = mysqli_real_escape_string($koneksi, $_POST['nomor_hp']);
    $jumlah       = (int)$_POST['jumlah'];

    if ($jumlah <= 0 || $jumlah > $produk['stok']) {
        $pesan_status = "<div class='alert alert-danger rounded-3 shadow-sm mb-4'><i class='bi bi-exclamation-octagon-fill me-2'></i>Jumlah pesanan tidak valid atau melebihi stok yang tersedia!</div>";
    } else {
        // Generate Auto ID Pesanan (TRX001, dst)
        $id_pesanan = generateID($koneksi, 'pesanan', 'id_pesanan', 'TRX');
        $total_harga = $jumlah * $produk['harga'];

        // Simpan Pesanan (secara default status = 'Pending')
        $insert = mysqli_query($koneksi, "INSERT INTO pesanan (id_pesanan, id_produk, nama_pembeli, nomor_hp, jumlah, total_harga, status) 
                                          VALUES ('$id_pesanan', '$id_produk', '$nama_pembeli', '$nomor_hp', $jumlah, $total_harga, 'Pending')");

        if ($insert) {
            // Kurangi Stok Otomatis
            mysqli_query($koneksi, "UPDATE produk SET stok = stok - $jumlah WHERE id_produk = '$id_produk'");
            
            $pesan_status = "
            <div class='alert alert-success rounded-4 shadow-sm p-4 mb-4 border-0'>
                <h4 class='fw-bold text-success mb-2'><i class='bi bi-check-circle-fill me-2'></i>Pemesanan Berhasil!</h4>
                <p class='mb-1'>Kode Transaksi Anda: <span class='badge bg-success fs-6'>$id_pesanan</span></p>
                <small class='text-muted d-block mb-3'>Terima kasih telah berbelanja di Toko Mila. Kami telah mencatat pesanan Anda.</small>
            </div>";
            
            // Reload Data Produk Terbaru
            $query = mysqli_query($koneksi, "SELECT produk.*, kategori.nama_kategori FROM produk JOIN kategori ON produk.id_kategori = kategori.id_kategori WHERE produk.id_produk = '$id_produk'");
            $produk = mysqli_fetch_assoc($query);
        } else {
            $pesan_status = "<div class='alert alert-danger rounded-3 shadow-sm mb-4'><i class='bi bi-x-circle-fill me-2'></i>Gagal memproses pesanan. Silakan coba beberapa saat lagi.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($produk['nama_produk']); ?> - Marketplace</title>
    
    <!-- Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
            color: #333;
        }

        .img-detail-container {
            background-color: #f8f9fa;
            position: relative;
            min-height: 400px;
        }

        .img-detail {
            width: 100%;
            height: 100%;
            object-fit: cover;
            max-height: 520px;
        }

        .badge-category {
            background: #56585b;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
        }

        .form-control:focus {
            border-color: #898b8f;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
        }

        .btn-checkout {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
            border: none;
            transition: all 0.3s ease;
        }

        .btn-checkout:hover {
            background: linear-gradient(135deg, #146c43 0%, #0f5132 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(25, 135, 84, 0.3);
        }
    </style>
</head>
<body>

<!-- Navbar Marketplace -->
<nav class="navbar navbar-expand-lg navbar-light sticky-top shadow-sm py-3"
     style="background:linear-gradient(90deg,#ffffff 0%, #606265 40%, #d6d6d6 100%);
            border-bottom:1px solid #ced4da;">
  <div class="container">
    <a class="navbar-brand fw-bold fs-4 d-flex align-items-center" href="index.php">
        <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 38px; height: 38px;">
            <i class="bi bi-bag-heart-fill fs-5"></i>
        </div>
        Marketplace
    </a>
  </div>
</nav>

<div class="container mb-5">
    <!-- Tombol Kembali -->
    <div class="mb-3">
        <a href="index.php" class="btn btn-white text-secondary shadow-sm rounded-pill px-3 py-2 fw-medium">
            <i class="bi bi-arrow-left me-1"></i> Kembali ke Beranda
        </a>
    </div>
    
    <!-- Status Pesan (Alert) -->
    <?= $pesan_status; ?>

    <!-- Main Card Detail -->
    <div class="card shadow-lg border-0 rounded-4 overflow-hidden bg-white">
        <div class="row g-0">
            <!-- Sisi Kiri: Gambar Produk -->
            <div class="col-lg-5 img-detail-container d-flex align-items-center justify-content-center">
                <img src="uploads/<?= $produk['foto']; ?>" class="img-detail" alt="<?= htmlspecialchars($produk['nama_produk']); ?>" onerror="this.src='https://via.placeholder.com/500x500?text=Toko+Mila'">
            </div>

            <!-- Sisi Kanan: Detail Informasi & Form Order -->
            <div class="col-lg-7 p-4 p-md-5">
                <div class="mb-2">
                    <span class="badge badge-category text-white fw-medium me-2">
                        <i class="bi bi-tag-fill me-1"></i><?= htmlspecialchars($produk['nama_kategori']); ?>
                    </span>
                    <span class="text-muted small">Kode: <?= $produk['id_produk']; ?></span>
                </div>

                <h2 class="fw-bold text-dark mb-2"><?= htmlspecialchars($produk['nama_produk']); ?></h2>
                
                <div class="d-flex align-items-baseline gap-2 mb-3">
                    <h2 class="text-primary fw-bold mb-0">Rp <?= number_format($produk['harga'], 0, ',', '.'); ?></h2>
                </div>

                <div class="d-flex align-items-center mb-4">
                    <?php if($produk['stok'] > 0): ?>
                        <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-2 fw-semibold">
                            <i class="bi bi-box-seam me-1"></i> Sisa Stok: <?= $produk['stok']; ?> pcs
                        </span>
                    <?php else: ?>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-3 py-2 fw-semibold">
                            <i class="bi bi-x-circle me-1"></i> Stok Habis
                        </span>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-file-text me-1"></i> Deskripsi Produk</h6>
                    <p class="text-muted lh-base" style="font-size: 0.95rem;">
                        <?= !empty($produk['deskripsi']) ? nl2br(htmlspecialchars($produk['deskripsi'])) : '<em>Tidak ada deskripsi rinci untuk produk ini.</em>'; ?>
                    </p>
                </div>

                <hr class="my-4">

                <!-- Form Pemesanan / Order -->
                <div class="bg-light p-4 rounded-4 border border-light-subtle">
                    <h5 class="fw-bold text-dark mb-3"><i class="bi bi-bag-check me-2 text-primary"></i>Form Pemesanan</h5>
                    
                    <?php if($produk['stok'] > 0): ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label fw-medium small text-secondary">Nama Lengkap Pembeli</label>
                            <input type="text" name="nama_pembeli" class="form-control rounded-3 py-2" required placeholder="Masukkan nama Anda">
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-7">
                                <label class="form-label fw-medium small text-secondary">Nomor HP / WhatsApp</label>
                                <input type="tel" name="nomor_hp" class="form-control rounded-3 py-2" required placeholder="Contoh: 081234567890">
                            </div>
                            <div class="col-md-5">
                                <label class="form-label fw-medium small text-secondary">Jumlah Beli</label>
                                <input type="number" id="jumlahInput" name="jumlah" class="form-control rounded-3 py-2" value="1" min="1" max="<?= $produk['stok']; ?>" required oninput="hitungTotal(this.value)">
                            </div>
                        </div>

                        <!-- Estimasi Total Bayar Real-time -->
                        <div class="d-flex justify-content-between align-items-center bg-white p-3 rounded-3 mb-4 border">
                            <span class="fw-medium text-secondary">Total Pembayaran:</span>
                            <span class="fw-bold fs-5 text-primary" id="totalBayar">Rp <?= number_format($produk['harga'], 0, ',', '.'); ?></span>
                        </div>

                        <button type="submit" name="submit_order" class="btn btn-checkout text-white btn-lg w-100 fw-bold py-3 rounded-3">
                            <i class="bi bi-bag-plus-fill me-2"></i> Beli Sekarang
                        </button>
                    </form>
                    <?php else: ?>
                        <div class="alert alert-warning text-center rounded-3 mb-0">
                            <i class="bi bi-exclamation-circle me-1"></i> Stok produk ini sedang kosong. Silakan cek produk lainnya di Toko Mila.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer Marketplace -->
<footer class="bg-white border-top py-4 mt-5">
    <div class="container text-center">
        <p class="mb-0 text-muted">&copy; <?= date('Y'); ?> <strong class="text-primary">Marketplace</strong>. Hak Cipta Dilindungi.</p>
    </div>
</footer>

<!-- Script hitung total bayar instan -->
<script>
    const hargaSatuan = <?= $produk['harga']; ?>;
    
    function hitungTotal(jumlah) {
        if (jumlah < 1) jumlah = 1;
        const total = jumlah * hargaSatuan;
        document.getElementById('totalBayar').innerText = 'Rp ' + total.toLocaleString('id-ID');
    }
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>